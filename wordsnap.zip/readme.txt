=== WordSnap ===
Contributors: 43081j
Tags: export, import, wordsnap
Requires at least: 3.0
Tested up to: 3.6
Stable tag: 0.0.1
License: GPLv2 or later

WordSnap allows you to quickly and easily take a Snap of your post to be imported into another WordSnap-enabled blog.

== Description ==

WordSnap allows you to take what we call a "Snap" of a post you have written, either through the edit page or the new post page.

Upon taking a Snap, you may save it to your computer and import it at a later time into another WordPress blog with WordSnap enabled.

You no longer need some bloated export/import system to handle this and can do it in just a couple of clicks, often just one!

== Installation ==

Upload the WordSnap plugin to your blog, activate it, then start posting. You may export a post any time by clicking the button at the top of the page during the creation or editing of a post.

== Changelog ==

= 0.0.1 =
* Initial release
